namespace $safeprojectname$.Content
{
	public enum Fonts
	{
		ChelseaMarket14,
		Verdana12
	}
}