namespace $safeprojectname$.Content
{
	public enum ComicStripImages
	{
		ComicStripBubble,
		ComicStripDragon,
		ComicStripPiggybank,
		ComicStripUnicorn
	}
}