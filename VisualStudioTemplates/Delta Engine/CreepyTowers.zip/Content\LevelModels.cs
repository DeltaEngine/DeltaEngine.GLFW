namespace $safeprojectname$.Content
{
	public enum LevelModels
	{
		LevelsChildsRoom,
		LevelsBathroom,
		LevelsLivingRoom
	}
}