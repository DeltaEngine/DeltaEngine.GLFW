namespace $safeprojectname$
{
	/// <summary>
	/// Loads Fruit$safeprojectname$ related content and settings
	/// </summary>
	public class Fruit$safeprojectname$Content : $safeprojectname$Content
	{
		public Fruit$safeprojectname$Content()
			: base("Fruit$safeprojectname$_")
		{
			DoBricksSplitInHalfWhenRowFull = true;
		}
	}
}