namespace $safeprojectname$.Screens
{
	/*TODO
	/// <summary>
	/// The contents of this file are auto generated. Do not edit, Editor will overwrite this.
	/// </summary>
	public partial class MainMenu : BaseGameScreen
	{
		public Button CreditsButton;
		public Button NewGameButton;
		public Button LoadButton;

		private void InitializeControls()
		{
			LoadUIScene("MainMenu");
			CreditsButton = FindUIControl<Button>("CreditsButton");
			NewGameButton = FindUIControl<Button>("NewGameButton");
			LoadButton = FindUIControl<Button>("LoadButton");
		}
	}
	 */
}
