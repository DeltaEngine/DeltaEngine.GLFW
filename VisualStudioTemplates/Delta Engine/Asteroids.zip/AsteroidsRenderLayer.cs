namespace $safeprojectname$
{
	public enum AsteroidsRenderLayer
	{
		Background,
		Rockets,
		Player,
		Asteroids,
		UserInterface
	}
}