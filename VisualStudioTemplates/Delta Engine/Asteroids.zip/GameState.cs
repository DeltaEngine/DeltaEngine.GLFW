namespace $safeprojectname$
{
	public enum GameState
	{
		Playing,
		GameOver,
	}
}