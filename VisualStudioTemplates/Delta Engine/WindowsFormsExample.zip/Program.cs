namespace $safeprojectname$
{
	class Program
	{
		public static void Main()
		{
			new ExampleForm();
		}
	}
}